// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Contact Submit Button Open Modal

btn.addEventListener('click', function(){

  modal.style.display = "block";

  let bericht = document.getElementById("bericht");
  bericht.innerHTML = "De volgende gegevens zijn opgeslagen";

  let naam = document.getElementById("naam");
  naam.innerHTML = "Naam: " + idNaam.value;
  naam.style.display = 'block';

  let telNumber = document.getElementById("telNumber");
  telNumber.innerHTML = "Tel: " + tnumb.value;

});

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

// Onblur method op de naam inputfield
let idNaam = document.getElementById("data-naam");
idNaam.addEventListener("blur", function(){
    if (idNaam.value === '') {

      let message = document.getElementById('message');
      message.innerHTML = 'Vul Jouw Naam In';
      message.style.border = '1px solid red';
      message.style.color = 'red';
      message.style.padding = '5px';
    }
    
    else {
      message.style.display = 'none';
    }
    
});

